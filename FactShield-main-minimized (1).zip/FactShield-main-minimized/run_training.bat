@echo off
title Training Fake News Detection Model
echo ========================================
echo    Training Fake News Detection Model
echo ========================================
echo.
echo Current directory: %CD%
echo.

cd /d D:\Data\MINI PROJECT\Backend\model
python train_model.py

echo.
echo ========================================
echo    Training Complete!
echo ========================================
pause