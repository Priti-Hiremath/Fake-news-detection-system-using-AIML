
const API_BASE_URL = 'http://localhost:5000';


const newsText = document.getElementById('newsText');
const analyzeBtn = document.getElementById('analyzeBtn');
const clearBtn = document.getElementById('clearBtn');
const loadingState = document.getElementById('loadingState');

const resultSectionWrapper = document.getElementById('analysisResultSection');
const resultPanel = document.getElementById('resultPanel');

const wordCounter = document.getElementById('wordCounter');
const pasteMode = document.getElementById('pasteMode');
const tabs = document.querySelectorAll('.tab-btn');

const realResult = document.getElementById('realResult');
const fakeResult = document.getElementById('fakeResult');
const fakeFill = document.getElementById('fakeFill');
const realFill = document.getElementById('realFill');
const confidenceScore = document.getElementById('confidenceScore');
const fakePercent = document.getElementById('fakePercent');
const realPercent = document.getElementById('realPercent');
const textLengthEl = document.getElementById('textLength');
const analysisTimeEl = document.getElementById('analysisTime');
const modelAccuracyEl = document.getElementById('modelAccuracy'); // NEW VARIABLE

const sampleNews = {
    fake: "BREAKING: Scientists discover eating chocolate causes instant weight loss! Big pharma is suppressing this secret. Eating large amounts of sugar actually shrinks your waistline overnight.",
    real: "The Federal Reserve announced today that it will maintain its benchmark interest rate steady, citing continued economic growth and stable inflation figures for the quarter."
};

tabs.forEach(btn => {
    btn.addEventListener('click', handleModeSwitch);
});

analyzeBtn.addEventListener('click', function(event) {
    event.preventDefault(); 
    analyzeNews();
});

clearBtn.addEventListener('click', function(event) {
    event.preventDefault();
    resetUI();
});

newsText.addEventListener('input', updateWordCounter);

function handleModeSwitch(e) {
    if (e) e.preventDefault(); 
    tabs.forEach(b => b.classList.remove('active'));
    e.currentTarget.classList.add('active');
    pasteMode.classList.add('active');
    newsText.disabled = false;
    newsText.focus();
}

async function analyzeNews() {
    const text = newsText.value.trim();
    
    document.querySelectorAll('.error-message').forEach(el => el.remove());
    
    const wordCount = text ? text.split(/\s+/).filter(w => w.length > 0).length : 0;
    
    if (wordCount < 10) {
        showError(`Text requires a minimum of 10 words (Current: ${wordCount})`);
        return;
    }
    if (wordCount > 1000) {
        showError(`Text cannot exceed 1000 words (Current: ${wordCount})`);
        return;
    }

    resultSectionWrapper.style.display = 'none'; 
    loadingState.classList.remove('hidden');
    loadingState.style.display = 'flex'; 

    const startTime = Date.now();

    try {
        const minimumDelay = new Promise(resolve => setTimeout(resolve, 1500));
        
        const fetchPromise = fetch(`${API_BASE_URL}/predict`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: text })
        });

        const [response] = await Promise.all([fetchPromise, minimumDelay]);

        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || 'Backend analysis failed');
        }

        const data = await response.json();

        const endTime = Date.now();
        const timeTaken = ((endTime - startTime) / 1000).toFixed(2);

        loadingState.classList.add('hidden');
        loadingState.style.display = 'none';
        
        displayResults(data, timeTaken, wordCount);

    } catch (error) {
        console.error(error);
        loadingState.classList.add('hidden');
        loadingState.style.display = 'none';
        showError("Backend Error: Cannot connect to AI. Is app.py running?");
    }
}

function displayResults(data, timeTaken, wordCount) {
    const isReal = data.prediction === 'REAL' || data.prediction === 'Real';
    const conf = parseFloat(data.confidence) || 95.0; 
    
    const fakeProb = isReal ? (100 - conf) : conf;
    const realProb = isReal ? conf : (100 - conf);

    if (isReal) {
        realResult.classList.remove('hidden');
        realResult.style.display = 'flex';
        fakeResult.classList.add('hidden');
        fakeResult.style.display = 'none';
    } else {
        fakeResult.classList.remove('hidden');
        fakeResult.style.display = 'flex';
        realResult.classList.add('hidden');
        realResult.style.display = 'none';
    }

    fakeFill.style.width = `${fakeProb}%`;
    realFill.style.width = `${realProb}%`;
    confidenceScore.textContent = `${conf.toFixed(1)}%`;
    fakePercent.textContent = `${fakeProb.toFixed(1)}%`;
    realPercent.textContent = `${realProb.toFixed(1)}%`;
    
    textLengthEl.textContent = `${wordCount} words`;
    analysisTimeEl.textContent = `${timeTaken}s`;

    // ADDED: Updates the UI with the 99.35% from Python
    if (data.model_accuracy) {
        modelAccuracyEl.textContent = `${data.model_accuracy}%`;
    }

    resultSectionWrapper.style.display = 'block'; 
    
    setTimeout(() => {
        resultSectionWrapper.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
}

function resetUI() {
    newsText.value = '';
    loadingState.classList.add('hidden');
    loadingState.style.display = 'none';
    
    resultSectionWrapper.style.display = 'none';
    
    wordCounter.textContent = '0 words';
    document.querySelectorAll('.error-message').forEach(el => el.remove());
    
    document.getElementById('detector').scrollIntoView({ behavior: 'smooth' });
    newsText.focus();
}

function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i><span>${message}</span>`;
    errorDiv.style.cssText = `
        background: rgba(239,68,68,0.2);
        color: #fecaca;
        padding: 1rem;
        border-radius: 12px;
        margin: 1rem 0;
        display: flex;
        align-items: center;
        gap: 10px;
        border: 1px solid rgba(239,68,68,0.3);
    `;

    document.querySelectorAll('.error-message').forEach(el => el.remove());
    document.querySelector('.input-area').parentNode.appendChild(errorDiv);
}

function updateWordCounter() {
    const text = newsText.value.trim();
    const wordCount = text ? text.split(/\s+/).filter(w => w.length > 0).length : 0;
    wordCounter.textContent = `${wordCount} words`;
}

window.useSample = function(type) {
    newsText.value = sampleNews[type];
    updateWordCounter();
}

window.analyzeAnother = function(event) {
    if(event) event.preventDefault();
    resetUI();
}

document.addEventListener('DOMContentLoaded', () => {
    const htmlTheme = document.getElementById('htmlTheme');
    const themeToggle = document.getElementById('themeToggle');
    const savedTheme = localStorage.getItem('theme') || 'light';
    htmlTheme.setAttribute('data-theme', savedTheme);

    themeToggle.addEventListener('click', (e) => {
        e.preventDefault();
        const currentTheme = htmlTheme.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        htmlTheme.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        themeToggle.querySelector('i').className = newTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    });
});

newsText.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        analyzeNews();
    }
    if (e.key === 'Escape') {
        e.preventDefault();
        resetUI();
    }
});