Large dataset files were removed to make this project uploadable to GitHub.
Original removed files:
- Fake.csv
- True.csv
