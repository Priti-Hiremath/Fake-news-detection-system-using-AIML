import pandas as pd
import numpy as np
import re
import nltk
import joblib
import os
from pathlib import Path
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.metrics import accuracy_score
from tqdm import tqdm
import warnings

warnings.filterwarnings('ignore')

# Download NLTK data
nltk.download('stopwords', quiet=True)

# Enable progress bar
tqdm.pandas()


class FakeNewsDetector:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=5000, stop_words='english')

        self.models = {
            'Logistic Regression': LogisticRegression(max_iter=1000),
            'Naive Bayes': MultinomialNB(),
            'Passive Aggressive': PassiveAggressiveClassifier(max_iter=1000)
        }

        self.best_model = None
        self.best_model_name = None
        self.best_accuracy = 0

        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))  # loaded once


    def load_data(self):
        """Load datasets"""
        print(" Loading datasets...")

        fake_path = 'D:/Data/MINI PROJECT/dataset/Fake.csv'
        true_path = 'D:/Data/MINI PROJECT/dataset/True.csv'

        if not os.path.exists(fake_path):
            fake_path = '../dataset/Fake.csv'
            true_path = '../dataset/True.csv'

        fake_df = pd.read_csv(fake_path)
        true_df = pd.read_csv(true_path)

        print(f"   Fake: {len(fake_df)} | Real: {len(true_df)} | Total: {len(fake_df) + len(true_df)}")

        fake_df['label'] = 0
        true_df['label'] = 1

        df = pd.concat([fake_df, true_df], axis=0, ignore_index=True)
        df = df.sample(frac=1, random_state=42).reset_index(drop=True)

        return df


    def clean_text(self, text):
        """Clean text"""
        if pd.isna(text) or not isinstance(text, str):
            return ""

        text = text.lower()
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        text = re.sub(r'\s+', ' ', text).strip()

        words = text.split()
        words = [
            self.stemmer.stem(word)
            for word in words
            if word not in self.stop_words
        ]

        return ' '.join(words)


    def preprocess_data(self, df):
        """Preprocess data"""
        print("🔄 Preprocessing text...")

        df = df.copy()

        if 'title' in df.columns and 'text' in df.columns:
            df['combined_text'] = df['title'].fillna('') + ' ' + df['text'].fillna('')
        elif 'text' in df.columns:
            df['combined_text'] = df['text'].fillna('')
        else:
            text_col = [col for col in df.columns if 'text' in col.lower()][0]
            df['combined_text'] = df[text_col].fillna('')

        # FAST with progress bar
        df['cleaned_text'] = df['combined_text'].progress_apply(self.clean_text)

        df = df[df['cleaned_text'].str.len() > 0]

        print(f"    {len(df)} samples ready")
        return df


    def prepare_features(self, df):
        """Create TF-IDF features"""
        print("🔧 Creating features...")

        X = self.vectorizer.fit_transform(df['cleaned_text'])
        y = df['label'].values

        print(f"    {X.shape[1]} features created")
        return X, y


    def train_models(self, X_train, X_test, y_train, y_test):
        """Train models"""
        print("\n Training Models")
        print("-" * 40)

        for name, model in self.models.items():
            model.fit(X_train, y_train)

            y_pred = model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)

            print(f"   {name:<20} {accuracy*100:.2f}%")

            if accuracy > self.best_accuracy:
                self.best_accuracy = accuracy
                self.best_model = model
                self.best_model_name = name

        print("-" * 40)
        print(f" Best: {self.best_model_name} ({self.best_accuracy*100:.2f}%)")


    def save_models(self):
        """Save models"""
        print("\n Saving models...")

        os.makedirs("saved_model", exist_ok=True)

        joblib.dump(self.best_model, "saved_model/fake_news_model.pkl")
        joblib.dump(self.vectorizer, "saved_model/tfidf_vectorizer.pkl")

        info = {
            'model_name': self.best_model_name,
            'accuracy': self.best_accuracy,
            'features': self.vectorizer.max_features
        }

        joblib.dump(info, "saved_model/model_info.pkl")

        print("    Models saved successfully")


def main():
    print("=" * 50)
    print(" FAKE NEWS DETECTION - TRAINING")
    print("=" * 50)

    detector = FakeNewsDetector()

    # Load data
    df = detector.load_data()

    # Preprocess
    df = detector.preprocess_data(df)

    # Features
    X, y = detector.prepare_features(df)

    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print(f" Train: {X_train.shape[0]} | Test: {X_test.shape[0]}")

    # Train
    detector.train_models(X_train, X_test, y_train, y_test)

    # Save
    detector.save_models()

    # Quick Test
    print("\n Quick Test:")
    test_texts = [
        "Miracle cure discovered! Big pharma hiding this!",
        "Federal Reserve announces interest rate decision"
    ]

    for text in test_texts:
        cleaned = detector.clean_text(text)
        vectorized = detector.vectorizer.transform([cleaned])
        pred = detector.best_model.predict(vectorized)[0]

        result = "REAL" if pred == 1 else "FAKE"
        print(f"   {result}: {text[:60]}...")

    print("\n" + "=" * 50)
    print(" TRAINING COMPLETED!")
    print("=" * 50)


if __name__ == "__main__":
    main()