@echo off
title Installing Fake News Detection Requirements
echo ========================================
echo    Installing Dependencies
echo ========================================
echo.

cd Backend

echo Installing Python packages...
pip install --upgrade pip
pip install Flask==2.3.3
pip install Flask-CORS==4.0.0
pip install scikit-learn==1.3.0
pip install pandas==2.0.3
pip install numpy==1.24.3
pip install joblib==1.3.2
pip install nltk==3.8.1
pip install python-dotenv==1.0.0

echo.
echo Downloading NLTK data...
python -c "import nltk; nltk.download('stopwords'); nltk.download('punkt')"

echo.
echo ========================================
echo    Installation Complete!
echo ========================================
echo.
pause